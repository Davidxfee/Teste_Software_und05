import pytest
from ecommerce.voucher import validar_voucher


@pytest.mark.parametrize(
    "valor, esperado",
    [
        # abaixo do limite inferior
        (49.99, False),
        (0.0, False),
        # exatamente no limite inferior
        (50.00, True),
        # logo acima do limite inferior
        (50.01, True),
        # valor típico dentro do intervalo
        (100.0, True),
        (250.5, True),
        # logo abaixo do limite superior
        (499.99, True),
        # exatamente no limite superior
        (500.00, True),
        # logo acima do limite superior
        (500.01, False),
        # valores negativos e muito grandes
        (-100.0, False),
        (1_000_000.0, False),
        # inteiros (compatibilidade de tipo)
        (50, True),
        (500, True),
        (49, False),
        (501, False),
    ],
)
def test_validar_voucher_boundaries(valor, esperado):
    assert validar_voucher(valor) is esperado


def test_valor_como_float_de_precisao():
    # teste para detectar problemas com comparações em ponto flutuante
    assert validar_voucher(50.0 + 0.0) is True
    assert validar_voucher(500.0 - 0.0) is True


def test_multiplas_chamadas_nao_alteram_estado():
    # garantir idempotência simples
    for v in (50.0, 100.0, 500.0, 49.99, 500.01):
        primeiro = validar_voucher(v)
        segundo = validar_voucher(v)
        assert primeiro == segundo
