# Mutmut - Testes para `validar_voucher`

Pequeno projeto com testes que implementam Análise de Valor Limite para a função `validar_voucher`.

## Instruções

1. Criar e ativar um virtualenv (recomendado):

```bash
python -m venv .venv
source .venv/bin/activate  # linux / mac
.\.venv\Scripts\activate   # windows
```

2. Instalar dependências:

```bash
pip install -r requirements.txt
```

3. Rodar os testes com pytest:

```bash
pytest -q
```

4. Executar o mutmut:

```bash
# executa mutmut (pode demorar dependendo da máquina)
mutmut run --paths-to-exclude tests

# ver resultados
mutmut results
```

Observação: `mutmut` procura por mutáveis no código fonte importável — a estrutura `src/` com pacote `ecommerce` facilita a importação.
